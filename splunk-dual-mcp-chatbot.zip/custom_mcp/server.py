from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class QueryRequest(BaseModel):
    query: str

@app.post("/execute")
def execute(req: QueryRequest):
    return {"data": {"message": "Custom MCP executed", "query": req.query}}
