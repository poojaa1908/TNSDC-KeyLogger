from openai import OpenAI
from config import OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

SYSTEM_PROMPT = '''
Classify request into one of:
1. official_usage_metrics
2. compliance_report
3. login_failures
3. top_clients_usage

Return JSON:
{
  "intent": "...",
  "parameters": {
    "time_range": "-24h",
    "limit": 5
  }
}
'''

def detect_intent(message):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message}
        ]
    )
    return response.choices[0].message.content
