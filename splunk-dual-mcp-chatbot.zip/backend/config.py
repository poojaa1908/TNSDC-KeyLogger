import os

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ORG_MCP_URL = "http://localhost:8100/execute"
CUSTOM_MCP_URL = "http://localhost:8200/execute"
