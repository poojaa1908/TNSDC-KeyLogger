import requests
from config import ORG_MCP_URL, CUSTOM_MCP_URL

def call_org_mcp(query):
    return requests.post(ORG_MCP_URL, json={"query": query}).json()

def call_custom_mcp(query):
    return requests.post(CUSTOM_MCP_URL, json={"query": query}).json()
