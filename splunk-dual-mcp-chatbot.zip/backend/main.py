from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json

from intent_engine import detect_intent
from query_registry import build_query
from mcp_clients import call_org_mcp, call_custom_mcp
from llm_summary import summarize

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str

@app.post("/chat")
def chat(req: ChatRequest):
    intent_response = detect_intent(req.message)
    parsed = json.loads(intent_response)

    query, mcp_type = build_query(parsed["intent"], parsed["parameters"])

    if mcp_type == "org":
        result = call_org_mcp(query)
    else:
        result = call_custom_mcp(query)

    final_response = summarize(req.message, result)

    return {
        "intent": parsed["intent"],
        "mcp_used": mcp_type,
        "query": query,
        "response": final_response
    }
