QUERY_MAP = {
    "official_usage_metrics": {
        "mcp": "org",
        "template": "index=official_logs earliest={time_range} | stats count by client_id"
    },
    "compliance_report": {
        "mcp": "org",
        "template": "index=audit_logs earliest={time_range}"
    },
    "login_failures": {
        "mcp": "custom",
        "template": "index=app_logs earliest={time_range} error=login_failure | stats count by client_id"
    },
    "top_clients_usage": {
        "mcp": "custom",
        "template": "index=usage_logs earliest={time_range} | stats count by client_id | sort -count | head {limit}"
    }
}

def build_query(intent, params):
    entry = QUERY_MAP.get(intent)
    if not entry:
        return None, None
    return entry["template"].format(**params), entry["mcp"]
